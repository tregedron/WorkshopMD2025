#!/bin/bash   
#SBATCH -J ec-density_test #name of job
#SBATCH -N 1 #number of nodes
#SBATCH -n 16 #number of cores
#SBATCH -o %x.e%j #out file path
#SBATCH -e %x.e%j.err #err file path
#SBATCH -t 20:00:00
#SBATCH -p MMM

module purge 
module load   Compiler/GNU/9.1.1 Compiler/Intel/20u4
ulimit -s unlimited
OMP_NUM_THREADS=1 

mpirun -n $SLURM_NTASKS /home/o.chalykh/soft/interface-lammps-mlip-2/lmp_intel_cpu_intelmpi -in lammps.txt
